import pygame
import time
import sprites
from settings import *

class Game(object):
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        pygame.font.init()
        self.screen = pygame.display.set_mode((WIDTH,HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        self.running = True
        self.ballImage = pygame.transform.scale(ballImage,(30,30))
        self.goalImage = pygame.transform.scale(goalImage,(400,200))
        self.score1 = 0
        self.score2 = 0
        self.myFont = pygame.font.SysFont('Light Pixel-7', 30)


 
    def new(self):
        self.goalSurface1 = self.myFont.render(f'{self.score1}', False, (255, 255, 255))
        self.goalSurface2 = self.myFont.render(f'{self.score2}', False, (255, 255, 255))
        self.all_sprites = pygame.sprite.Group()
        self.wallSprites = pygame.sprite.Group()
        self.player = sprites.Player(self,2)
        self.AI = sprites.AI(self,10)
        self.ball = sprites.Ball(self, BALL_r)
        self.field = sprites.Field(0, HEIGHT-40, WIDTH, 40)
        self.gP1 = sprites.Goalpost(0, HEIGHT-120, PLAYER_length*2,80)
        self.gP2 = sprites.Goalpost(WIDTH-PLAYER_length*2,HEIGHT-120,PLAYER_length*2,80)
        self.wall1 = sprites.Wall(0, -10000, PLAYER_length,HEIGHT-120+10000)
        self.wall2 = sprites.Wall(WIDTH-PLAYER_length,-10000 , PLAYER_length,HEIGHT-120+10000)
        self.wallSprites.add(self.wall1, self.wall2)
        self.all_sprites.add(self.field)
        self.all_sprites.add(self.gP1,self.gP2)
        self.all_sprites.add(self.wall1,self.wall2)
        self.all_sprites.add(self.player,self.AI,self.ball)
        self.run()

    def run(self):
        self.playing = True
        while self.playing:
            self.clock.tick(FPS)
            self.events()
            self.update()
            self.draw()

    def update(self):
        self.all_sprites.update()
        playerOnGround = pygame.sprite.collide_rect(self.player,self.field)
        AIOnGround = pygame.sprite.collide_rect(self.AI,self.field)
        ballHitPlayer = pygame.sprite.collide_rect(self.ball,self.player)
        ballHitAI = pygame.sprite.collide_rect(self.ball,self.AI)
        ballHitField = pygame.sprite.collide_rect(self.ball,self.field)
        ballHitWall1 = pygame.sprite.collide_rect(self.ball,self.wall1)
        ballHitWall2 = pygame.sprite.collide_rect(self.ball,self.wall2)
        ballHitGoal1 = pygame.sprite.collide_rect(self.ball,self.gP1)
        ballHitGoal2 = pygame.sprite.collide_rect(self.ball,self.gP2)
        if playerOnGround:
            self.player.pos.y = self.field.rect.top
            self.player.vel.y = 0
        if AIOnGround:
            self.AI.pos.y = self.field.rect.top
            self.AI.vel.y = 0
        if ballHitPlayer:
            self.ball.vel = (BALL_m-PLAYER_m)/(BALL_m+PLAYER_m)*self.ball.vel + 2*PLAYER_m/(PLAYER_m+BALL_m)*self.player.vel
        if ballHitAI:
            self.ball.vel = (BALL_m-AI_m)/(BALL_m+AI_m)*self.ball.vel + 2*AI_m/(AI_m+BALL_m)*self.AI.vel
        if ballHitField:
            self.ball.pos.y = self.field.rect.top-0.5
            self.ball.vel.y = self.ball.vel.y*-0.7
        if self.ballHitWall(self.wall1):
            self.ball.vel.x = self.ball.vel.x*-0.7
            self.ball.pos.x = self.ball.pos.x+5
        elif self.ballHitWall(self.wall2):
            self.ball.vel.x = self.ball.vel.x*-0.7
            self.ball.pos.x = self.ball.pos.x-5


    def ballHitWall(self,wall):
        if pygame.sprite.collide_rect(self.ball,wall):
            return True
        return False

    def ballHitGoal(self,goal):
        if pygame.sprite.collide_rect(self.ball,goal):
            return True
        return False

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                if self.playing:
                    self.playing = False
                self.running = False

    def draw(self):
        if self.ballHitGoal(self.gP1):
            self.screen.blit(self.goalImage,(WIDTH//7,HEIGHT//4))
            pygame.display.update()
            self.ball.vel.x = 0.1*self.ball.vel.x
            self.player.vel.x = 0
            self.AI.vel.x = 0
            self.score2 +=1
            pygame.time.wait(3000)
            self.new()
        elif self.ballHitGoal(self.gP2):
            self.screen.blit(self.goalImage,(WIDTH//7,HEIGHT//4))
            pygame.display.update()
            self.ball.vel.x = 0.1*self.ball.vel.x
            self.player.vel.x = 0
            self.AI.vel.x = 0
            self.score1 +=1
            pygame.time.wait(3000)
            self.new()
        self.screen.fill((0,0,0))
        self.all_sprites.draw(self.screen)
        self.screen.blit(self.ballImage,(self.ball.rect.topleft))
        self.screen.blit(self.goalSurface1,(WIDTH//5,HEIGHT//6))
        self.screen.blit(self.goalSurface2,(4*WIDTH//5,HEIGHT//6))
        pygame.display.flip()

    def activateScreen(self):
        pass

game = Game()
# game.activateScreen(start)
while game.running:
    game.new()
    # game.activateScreen(go)

pygame.quit()