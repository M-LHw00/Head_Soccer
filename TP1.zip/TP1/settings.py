import pygame
TITLE = '11HEAD SOCCER2'
WIDTH = 500
HEIGHT = 500
FPS = 70
MARGIN = 50
GRAV = 2
pX,pY = WIDTH//4, MARGIN

goalImage = pygame.image.load('goal.png')
ballImage=pygame.image.load('ball.png')

#PLAYER PROPOERTIES
PLAYER_a = 0.5
PLAYER_f = -0.15
PLAYER_length = 20
PLAYER_j = -20
PLAYER_m = 10

AI_a = 0.5
AI_f = -0.15
AI_length = 20
AI_j = -20
AI_m = 10

#BALL PROPERTY
BALL_a = 0.5
BALL_m = 1
BALL_r = 10