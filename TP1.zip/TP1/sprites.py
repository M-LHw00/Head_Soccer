import pygame
from settings import *
vec = pygame.math.Vector2
class Player(pygame.sprite.Sprite):
  # ,r,x,y,,speed,power,skill,color
    def __init__(self, game,power): #color changed to character later
        pygame.sprite.Sprite.__init__(self)
        self.game= game
        self.power = power
        self.image = pygame.Surface((60,60))
        self.image.fill((255,255,255))
        self.rect= self.image.get_rect()
        self.length = PLAYER_length
        self.pos = vec(WIDTH/4, HEIGHT/2)
        self.vel = vec(0,0)
      
    def update(self):
      self.acc = vec(0,GRAV)
      keys = pygame.key.get_pressed()
      if keys[pygame.K_RIGHT] and self.pos.x+self.length < WIDTH:
          self.acc.x = PLAYER_a
      elif keys[pygame.K_LEFT] and self.pos.x-self.length > 0:
          self.acc.x = -PLAYER_a
      if keys[pygame.K_UP]:
        self.jump()
      if keys[pygame.K_SPACE]:
        self.kick()
      self.acc.x += self.vel.x*PLAYER_f
      self.vel += self.acc
      self.pos.x += 2*self.vel.x
      self.pos.y += self.vel.y
      if self.pos.x-self.length < 0:
        self.pos.x = self.length
      elif self.pos.x+self.length > WIDTH:
        self.pos.x = WIDTH-self.length
      self.rect.midbottom = self.pos

    def getDistance(self,pos1,pos2):
      return ((pos1[0]-pos2[0])**2+(pos1[1]-pos2[1])**2)**0.5

    # def touch(self):
    #   playerPos = self.rect.center
    #   ballPos = self.game.ball.rect.center
    #   distance = self.getDistance(playerPos,ballPos)
    #   if distance <=100:
    #     print('old',self.game.ball.vel)
    #     newVel = 2*(2*PLAYER_m*self.vel)/(PLAYER_m+BALL_m)
    #     print('new',newVel)
    #     self.game.ball.vel = newVel

    def kick(self):
      playerPos = self.rect.center
      ballPos = self.game.ball.rect.center
      distance = self.getDistance(playerPos,ballPos)
      if distance <=70:
        self.game.ball.vel = (BALL_m-PLAYER_m)/(BALL_m+PLAYER_m)*self.game.ball.vel + 2*PLAYER_m/(PLAYER_m+BALL_m)*self.vel*self.power

    def jump(self):
    #only jump when on platform
      self.rect.y += 1
      hits = pygame.sprite.collide_rect(self, self.game.field)
      self.rect.y -= 1
      if hits:
        self.vel.y = PLAYER_j

class AI(pygame.sprite.Sprite):
  # ,r,x,y,,speed,power,skill,color
    def __init__(self, game,power): #color changed to character later
        pygame.sprite.Sprite.__init__(self)
        self.game= game
        self.power = power
        self.image = pygame.Surface((60,60))
        self.image.fill((0,255,255))
        self.rect= self.image.get_rect()
        self.length = PLAYER_length
        self.pos = vec(3*WIDTH/4, HEIGHT/2)
        self.vel = vec(0,0)
      
    def update(self):
      self.acc = vec(0,GRAV)
      keys = pygame.key.get_pressed()
      if self.game.ball.pos.x > self.pos.x and self.pos.x+self.length < WIDTH:
          self.acc.x = AI_a
      elif self.game.ball.pos.x < self.pos.x and self.pos.x-self.length > 0:
          self.acc.x = -AI_a
      if self.game.ball.pos.y > self.pos.y:
        self.jump()
      # if keys[pygame.K_SPACE]:
      #   self.kick()
      self.acc.x += self.vel.x*AI_f
      self.vel += self.acc
      self.pos.x += 2*self.vel.x
      self.pos.y += self.vel.y
      if self.pos.x-self.length < 0:
        self.pos.x = self.length
      elif self.pos.x+self.length > WIDTH:
        self.pos.x = WIDTH-self.length
      self.rect.midbottom = self.pos

    def getDistance(self,pos1,pos2):
      return ((pos1[0]-pos2[0])**2+(pos1[1]-pos2[1])**2)**0.5

    # def touch(self):
    #   playerPos = self.rect.center
    #   ballPos = self.game.ball.rect.center
    #   distance = self.getDistance(playerPos,ballPos)
    #   if distance <=100:
    #     print('old',self.game.ball.vel)
    #     newVel = 2*(2*PLAYER_m*self.vel)/(PLAYER_m+BALL_m)
    #     print('new',newVel)
    #     self.game.ball.vel = newVel

    def kick(self):
      AIPos = self.rect.center
      ballPos = self.game.ball.rect.center
      distance = self.getDistance(AIPos,ballPos)
      if distance <=70:
        self.game.ball.vel = 3*(2*AI_m*self.vel)/(AI_m+AI_m)

    def jump(self):
    #only jump when on platform
      self.rect.y += 1
      hits = pygame.sprite.collide_rect(self, self.game.field)
      self.rect.y -= 1
      if hits:
        self.vel.y = PLAYER_j

class Ball(pygame.sprite.Sprite):
  def __init__(self, game, r):
    pygame.sprite.Sprite.__init__(self)
    self.game=game
    self.player = Player(self.game,10)
    self.image = pygame.Surface((30,30))
    self.image.fill((0,0,0))
    self.rect= self.image.get_rect()
    self.pos = vec(WIDTH//2,0)
    self.vel = vec(0,0)
    self.acc = vec(0,GRAV)
    self.length = r

  def update(self):
      self.acc = vec(0,GRAV)
      # self.acc.x += self.vel.x
      # print('velocity',self.vel,'acc',self.acc)
      self.vel.y += self.acc.y
      self.pos += self.vel #+ 0.5 * self.acc
      if self.pos.x-self.length < 0:
        self.pos.x = self.length
      elif self.pos.x+self.length > WIDTH:
        self.pos.x = WIDTH-self.length
      self.rect.midbottom = self.pos
  
  def getCenterPos(self):
    return self.rect.center

  
class Field(pygame.sprite.Sprite):
  def __init__(self,x,y,width,height):
    pygame.sprite.Sprite.__init__(self)
    self.image = pygame.Surface((width,height))
    self.image.fill((0,255,0))
    self.rect = self.image.get_rect()
    self.rect.x = x
    self.rect.y = y 

class Goalpost(pygame.sprite.Sprite):
  def __init__(self,x,y,w,h):
    pygame.sprite.Sprite.__init__(self)
    self.image = pygame.Surface((w,h))
    self.image.fill((0,0,255))
    self.rect = self.image.get_rect()
    self.rect.x = x
    self.rect.y = y 

class Wall(pygame.sprite.Sprite):
  def __init__(self,x,y,w,h):
    pygame.sprite.Sprite.__init__(self)
    self.image = pygame.Surface((w,h))
    self.image.fill((255,0,255))
    self.rect = self.image.get_rect()
    self.rect.x = x
    self.rect.y = y 

