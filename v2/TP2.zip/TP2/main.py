import pygame
import game
import splash
from settings import *

pygame.init()
pygame.mixer.init()
pygame.font.init()



splashScreen = splash.SplashScreen()
gamePlay = game.Game()


def gameIntro():

    running = True
    myFont = pygame.font.SysFont('Husky Stash', 50)
    title = myFont.render('THIS WILL DEFINITELY IMRPOVE', False, (255, 127, 80))
    spriteCounter = 0
    charL = pImageList
    step = 170
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        if step >700:
            running = False
        gamePlay.screen.fill((255,255,255))
        spriteCounter = (1 + spriteCounter) % len(pImageList)
        gamePlay.screen.blit(logoImage,(WIDTH//2-70,HEIGHT//2-30))
        image = charL[spriteCounter]
        gamePlay.screen.blit(image,(step,50))
        gamePlay.screen.blit(title,(50,70))
        step+=5
        pygame.display.update()

# splashScreen.run()
# while splashScreen.playing:
#     splashScreen.update()
gameIntro()
gamePlay.new()
while gamePlay.running:
    # if gamePlay.scored:
    #     gamePlay.goalHandling.drawGoal()
    gamePlay.update()

pygame.quit()


# import cProfile
# cProfile.run('run()')
