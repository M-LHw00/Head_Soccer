import pygame
import game
import sprites 
import player_object
from settings import *
import math

vec = pygame.math.Vector2

class AI(pygame.sprite.Sprite):
  # ,r,x,y,,speed,power,skill,color
    def __init__(self,game): #color changed to character later
        pygame.sprite.Sprite.__init__(self)
        self.r = AI_r
        self.mass = AI_m
        self.game = game
        self.image = pygame.Surface((AI_r*2,AI_r*2),pygame.SRCALPHA)
        self.imageL = pogbaL
        self.rect = self.image.get_rect()
        self.vel = vec(0,0)
        self.acc = vec(0,0)
        self.pos = vec(3*WIDTH/4, HEIGHT/2)
        self.length = PLAYER_length
        self.tanAI = math.atan2(self.vel.y,self.vel.x)
        self.attackMode = None
        self.attackL = [0,1,2,3,4]
        self.defenseL = [0,1,2]
        self.attackModeOption = 0
        self.defenseModeOption = 0
        self.hasBall = False
        self.spriteCounter = 0
        self.touchCounter = 0

    def checkAttackMode(self):
        #Ball is on the player's half
        if self.game.ball.pos.x<=WIDTH//2:
            # AI is left to the ball and Player is closer to the ball
            if self.game.ball.pos.x - self.pos.x  > self.game.ball.r + self.r+5  and (self.distance(self.game.player.pos, self.game.ball.pos) <= self.distance(self.pos,self.game.ball.pos)):
                self.attackMode = False
                self.defenseModeOption = self.defenseL[0]
            #AI is left to the ball and AI is closer to the ball
            elif (self.game.ball.pos.x - self.pos.x > self.game.ball.r + self.r+5  and (self.distance(self.game.player.pos, self.game.ball.pos) >= self.distance(self.pos,self.game.ball.pos))
                and not self.game.ball.isJumping):
                self.attackMode = True
                self.attackModeOption = self.attackL[0]
            #AI is right to the ball and Player is closer to the ball    
            elif (self.game.ball.pos.x - self.pos.x < self.game.ball.r + self.r+5 and (self.distance(self.game.player.pos, self.game.ball.pos) <= self.distance(self.pos,self.game.ball.pos))
                and not self.game.ball.isJumping):
                self.attackMode = True
                self.attackModeOption = self.attackL[1]
            #AI is right to the ball and AI is closer to the ball
            elif (self.game.ball.pos.x - self.pos.x < self.game.ball.r + self.r+5 and (self.distance(self.game.player.pos, self.game.ball.pos) >= self.distance(self.pos,self.game.ball.pos))
            and not self.game.ball.isJumping):
                self.attackMode = True
                self.attackModeOption = self.attackL[2]
        #Ball is on the AI's half
        else:
            #AI is closer to the ball and the AI is left to the ball
            if (self.distance(self.game.player.pos, self.game.ball.pos) >= self.distance(self.pos,self.game.ball.pos)
                and self.pos.x < self.game.ball.pos.x):
                self.attackMode = False
                self.defenseModeOption = self.defenseL[1]
            #AI is closer to the ball and the AI is right to the ball
            elif (self.distance(self.game.player.pos, self.game.ball.pos) >= self.distance(self.pos,self.game.ball.pos)
                and self.pos.x > self.game.ball.pos.x):
                self.attackMode = True
                self.attackModeOption = self.attackL[3]
            #Player is closer to the ball and AI is left to the ball
            elif (self.distance(self.game.player.pos, self.game.ball.pos) <= self.distance(self.pos,self.game.ball.pos)
                and self.pos.x < self.game.ball.pos.x):
                self.attackMode = False
                self.defenseModeOption = self.defenseL[2]
            #Player is closer to the ball and AI is right to the ball                
            elif (self.distance(self.game.player.pos, self.game.ball.pos) <= self.distance(self.pos,self.game.ball.pos)
                and self.pos.x > self.game.ball.pos.x):
                self.attackMode = True
                self.attackModeOption = self.attackL[4]

    def checkBallPossession(self):
        # if the ball is very close to AI
        if self.distance(self.pos,self.game.ball.pos) <= self.r + self.game.ball.r+10: #if the ball is in front of AI
            self.hasBall = True
        else:
            self.hasBall = False
    
    def ballReachingWall1(self):
        if self.game.ball.pos.x - self.wall1.rect.right<= 40+self.game.ball.r:
            return True
        else: return False

    def ballReachingWall2(self):
        if self.game.ball.pos.x - self.wall2.rect.left<= 40-self.game.ball.r:
            return True
        else: return False

    def chaseBall(self):
        if (math.isclose(self.pos.x, self.game.ball.pos.x, abs_tol=self.r+self.game.ball.r+5)
         and not math.isclose(self.game.field.rect.top-self.game.ball.pos.y,self.game.field.rect.top-self.game.ball.r,abs_tol=0.2) 
         and math.isclose(self.game.ball.angle,math.pi,abs_tol=0.5)):
            self.acc.x = AI_a
        elif self.game.ball.pos.x > self.pos.x:
            self.acc.x = AI_a
        elif self.game.ball.pos.x<self.pos.x:
            self.acc.x = -AI_a
    # def wait(self):
    #     self.vel.x = 0
    def distance(self,pos1,pos2):
        return ((pos1[0]-pos2[0])**2+(pos1[1]-pos2[1])**2)**0.5

    def jump(self):
    #only jump when on platform
        ##print(f"I jumped because I'm in attackmode: {self.attackMode} and {self.attackModeOption} and {self.defenseModeOption}")
        self.rect.y += 1
        onFloor = pygame.sprite.collide_rect(self, self.game.field)
        self.rect.y -= 1
        if onFloor:
            self.vel.y = PLAYER_j

    def update(self):
        self.acc = vec(0,2)
        self.spriteCounter = (1 + self.spriteCounter) % len(self.imageL)
        self.checkAttackMode()
        self.checkBallPossession()
        # keys = pygame.key.get_pressed()
        #print('Attack mode is',self.attackMode)
        #print('AI has the ball',self.hasBall)
        #print(f'The attack option is {self.attackModeOption}')
        #print(f'The defense option is {self.defenseModeOption}')
        #print()
        #ATTACK MODE
        if self.attackMode:
            #Attack mode but doesn't have the ball --> aggressive
            if not self.hasBall:
                #Ball on player's half and
                #AI is left to the ball and AI is closer to the ball
                if self.attackModeOption == 0:
                    if self.pos.x > self.game.ball.pos.x:
                        self.acc.x = -AI_a
                    elif self.pos.x < self.game.ball.pos.x:
                        self.chaseBall()
                #AI is right to the ball and player is closer to the ball
                elif self.attackModeOption == 1:
                    self.chaseBall() # This will make the AI to possess the ball
                #AI is right to the ball and AI is closer to the ball
                elif self.attackModeOption == 2:
                    self.acc.x = -AI_a
                #Ball on AI's half and
                #AI is right to the ball and AI is closer to the ball
                elif self.attackModeOption == 3:
                    self.acc.x = -AI_a
                #AI is right to the ball  and player is closer to the ball
                elif self.attackModeOption == 4:
                    self.acc.x = -AI_a
            #Attack mode and has the ball --> very aggressive
            else:
                if not math.isclose(self.game.field.rect.top-self.game.ball.pos.y,self.game.field.rect.top-self.game.ball.r,abs_tol=0.2) and math.isclose(self.game.ball.angle,math.pi,abs_tol=0.5):
                    #print("TRUe")
                    self.acc.x = AI_a
                #Ball on player's half and
                #AI is left to the ball and AI is closer to the ball
                elif self.attackModeOption == 0:
                    if self.pos.x > self.game.ball.pos.x-10:
                        self.acc.x = -AI_a
                    elif self.pos.x < self.game.ball.pos.x+10:
                        self.acc.x = AI_a
                        if (math.isclose(self.pos.x, self.game.ball.pos.x, abs_tol=self.r+self.game.ball.r+5)
                            and math.isclose(self.game.field.rect.top-self.game.ball.pos.y,self.game.field.rect.top-self.game.ball.r,abs_tol=0.2)):
                            self.jump()
                #AI is right to the ball and player is closer to the ball
                elif self.attackModeOption == 1 :
                    self.acc.x = -AI_a
                #AI is right to the ball and AI is closer to the ball
                elif self.attackModeOption == 2:
                    self.acc.x = -AI_a
                #Ball on AI's half and
                #AI is right to the ball and AI is closer to the ball
                elif (self.attackModeOption == 3 and
                     math.isclose(self.game.field.rect.top-self.game.ball.pos.y,self.game.field.rect.top-self.game.ball.r,abs_tol=0.2)):
                    self.acc.x = -AI_a
                #AI is right to the ball  and player is closer to the ball
                elif self.attackModeOption == 4:
                    self.acc.x = -AI_a
        #DEFENSE MODE
        else:
            if not math.isclose(self.game.field.rect.top-self.game.ball.pos.y,self.game.field.rect.top-self.game.ball.r,abs_tol=0.2) and math.isclose(self.game.ball.angle,math.pi,abs_tol=0.5):
                #print("Defense TRUe")
                self.acc.x = AI_a
            #Ball on player's half and AI is left to the ball and Player is closer to the ball
            elif self.defenseModeOption == 0:
                if not math.isclose(self.pos.x,(WIDTH-PLAYER_length*5),abs_tol=20):
                    self.acc.x = AI_a
                if (math.isclose(self.pos.x, self.game.ball.pos.x, abs_tol=self.r+self.game.ball.r+5)
                    and math.isclose(self.game.field.rect.top-self.game.ball.pos.y,self.game.field.rect.top-self.game.ball.r,abs_tol=0.5)):
                    self.jump()
                
            #Ball on AI's half and
            #AI is left to the ball and closer to the ball
            elif self.defenseModeOption == 1:
                if not math.isclose(self.pos.x,(WIDTH-PLAYER_length*5),abs_tol=20):
                    self.acc.x = AI_a
                if (math.isclose(self.pos.x, self.game.ball.pos.x, abs_tol=self.r+self.game.ball.r+5)
                    and  math.isclose(self.game.field.rect.top-self.game.ball.pos.y,self.game.field.rect.top-self.game.ball.r,abs_tol=0.5)):
                    self.jump()
            elif self.defenseModeOption == 2:
                if not math.isclose(self.pos.x,(WIDTH-PLAYER_length*5),abs_tol=20):
                    self.acc.x = AI_a
                if (math.isclose(self.pos.x, self.game.ball.pos.x, abs_tol=self.r+self.game.ball.r+5)
                    and  math.isclose(self.game.field.rect.top-self.game.ball.pos.y,self.game.field.rect.top-self.game.ball.r,abs_tol=0.5)):
                    self.jump()

        if not self.game.scored:
            self.acc.x += self.vel.x*AI_f
            self.vel += self.acc
            self.pos.x += 2*self.vel.x
            self.pos.y += self.vel.y
            if self.pos.x-self.length < 0:
                self.pos.x = self.length    
            elif self.pos.x+self.length > WIDTH:
                self.pos.x = WIDTH-self.length  
        self.rect.center = self.pos 

 

